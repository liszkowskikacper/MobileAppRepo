import java.util.Scanner;
public class main
{
    public static void main (String[] args)
    {
        Scanner sc = new Scanner(System.in);
        boolean graj = true;
        while(graj == true) {
            int i = 0;
            while (i < 3 || i > 10) {
                System.out.print("Ile kości chcesz rzucić? ");
                i = sc.nextInt();
                sc.nextLine();
            }
            int[] Dices = new int[i];
            for (int j = 0; j < Dices.length; j++) {
                Dices[j] = ((int) (Math.random() * 6) + 1);
                System.out.println("Kostka " + (j + 1) + ": " + Dices[j]);
            }
            int suma = 0;
            for (int j = 1; j <= 6; j++) {
                int amount = 0;
                for (int k = 0; k < Dices.length; k++) {
                    if (j == Dices[k]) {
                        amount ++;
                    }
                }
                if (amount > 1){
                    suma += amount * j;
                }
            }
            System.out.println("Suma punktów to " + suma);
            System.out.println("Czy chcesz grać dalej?");
            String a = sc.nextLine();
            switch(a){
                case "t":
                    break;
                case "n":
                    graj = false;
                    break;
            }

        }
    }
}
